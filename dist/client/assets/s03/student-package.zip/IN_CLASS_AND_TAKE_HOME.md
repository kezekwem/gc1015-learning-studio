# Your lab route

Open LAB01_Student_Lab.html or the PDF edition. Each Part keeps its purpose, exact cell, formula, expected behavior, explanation and checkpoint together.

In class: Parts A/B/C/D calculations take 6/7/6/7 minutes. The 12-minute evidence clinic returns to A–C explanations and SPSS evidence. Continue Part D interpretation and the existing post-class work from the guide’s Resume checkpoint. Existing assessment and submission rules still apply.
